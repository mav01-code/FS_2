function Test() {
    return (
        <>
            navigate("/file:///C:/Users/VINAY/AppData/Local/Microsoft/Windows/INetCache/IE/2S9M3D48/login.html")
            </>
    )
}
export default Test