import React from "react"

function Content(){
    return(
        <div className="description">
            <h5>City:Warangal</h5>
            <h5>University:SVS</h5>

        </div>
    )
}
export default Content