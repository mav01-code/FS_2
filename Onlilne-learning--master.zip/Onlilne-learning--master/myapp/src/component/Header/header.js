import React from 'react';
import './header.css';

function Header() {
    return (
        <div className='profile'>
            <h5>This Is Vinay</h5>
        </div>
    )
}
export default Header


